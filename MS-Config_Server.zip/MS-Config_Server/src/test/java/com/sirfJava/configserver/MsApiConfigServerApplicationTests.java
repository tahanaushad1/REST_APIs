package com.sirfJava.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsApiConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
